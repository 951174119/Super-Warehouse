
"""
1.读取图像，在指定名称的窗口中显示；
2.在显示窗口，进行鼠标点击操作：
  只有前三次按下鼠标左键时，才顺序获取每次点击处图像的像素坐标(横坐标，纵坐标)
  同时，将像素坐标添加至列表中。
3.按下ESC键，关闭窗口，释放所有窗口资源。

"""
import cv2

# 1.读取原始图像，生成副本(后面的只在副本上进行)
img0 = cv2.imread('cxk.png')
img = img0.copy()

# 2. 定义左键点击事件响应函数
def on_EVENT_LBUTTONDOWN(event, x, y, flags, param):
    global point_list
    a = len(point_list)
    if(a<3):
        if event == cv2.EVENT_LBUTTONDOWN:
            point_list.append([x,y])
            cv2.circle(img, (x, y), 3, (255, 0, 0), thickness = -1)
            
            #添加文字
            cv2.putText(img, str(a+1), (x, y), cv2.FONT_HERSHEY_PLAIN,
                        1.0, (0,255,0), thickness = 1)
            cv2.imshow("window 2", img)
          
# 3.创建空列表，用于存放鼠标点击获取的图像像素坐标
point_list = list()    

# 4.创建名称为"window 1"的窗口，可任意改变大小；在该窗口显示图像img0
cv2.namedWindow("window 1",flags= cv2.WINDOW_NORMAL | cv2.WINDOW_FREERATIO)
cv2.imshow("window 1", img0)

# 5.创建名称为"window 2"的窗口，可任意改变大小；在该窗口显示图像img;
#   同时，设置on_EVENT_LBUTTONDOWN为在"window 2"窗口进行鼠标操作的回调函数
#   进行鼠标操作
cv2.namedWindow("window 2",flags= cv2.WINDOW_NORMAL | cv2.WINDOW_FREERATIO)
cv2.imshow("window 2", img)
cv2.setMouseCallback("window 2", on_EVENT_LBUTTONDOWN)
while(1):
    if cv2.waitKey(0): # 按ESC键，循环终止，释放所有窗口资源
        break

# 6.释放所有窗口资源
cv2.destroyAllWindows()

