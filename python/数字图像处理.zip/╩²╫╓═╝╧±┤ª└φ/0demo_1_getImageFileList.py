


import cv2
from skimage.io import imsave
import glob 
                               # 有助于文件的遍历
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['simhei'] # 添加中文字体为简黑
plt.rcParams['axes.unicode_minus'] =False

import os

# In[2]:图像处理
# (1)获取指定文件夹的图像文件名列表

str1 = 'cxk/'
str2 = '01ImagesOUT/'

img_list = glob.glob(str1 + '*.png')
img_list  = img_list + glob.glob(str1 + '*.jpg')
img_list  = img_list + glob.glob(str1 + '*.jpeg')   


# (2)遍历文件名列表的每个文件  
for i, img_path in enumerate(img_list):
      

      # A.以灰度模式读取原始图像、可视化
      # cv2.IMREAD_COLOR：加载彩色图片，这个是默认参数，可以直接写1。
      # cv2.IMREAD_GRAYSCALE：以灰度模式加载图片，可以直接写0。
      # cv2.IMREAD_UNCHANGED：包括alpha，可以直接写-1
      
      print('%d----'%(i+1), img_path)
      
      (filepath,tempfilename) = os.path.split(img_path) 
      (Myfilename,extension) = os.path.splitext(tempfilename) # 分离文件名的后缀
      
      # ===后面会使用分离出的文件名Myfilename，生成其它的文件名
      
      imgIn  = cv2.imread(img_path)    

      plt.figure(figsize = (10,10))

      plt.imshow(imgIn)
      plt.title('输入图像--'+ Myfilename, size = 20)
      plt.xticks([])
      plt.yticks([])  
            
      plt.show()      
                  

      # 将该图像转存为至其它位置，文件名是在Myfilename基础上产生的
      imsave(str2+ Myfilename +'_out.jpeg',imgIn )     
      
