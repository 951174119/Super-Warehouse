# -*- coding: utf-8 -*-
"""
Created on Fri Sep 17 11:23:17 2021

@author: dell
"""

import numpy as np
import cv2 as cv

# 1.读取图像，获取图像的行数、列数、颜色通道数目
imgInput = cv.imread('bean.png', 1)
rows, cols, channels = imgInput.shape

# 2.按照统一顺序，给出输入图像的三个点以及在输出图像中对应的位置
#   相当于明确了三个对应点对
p1 = np.float32([[0,0],        [cols-1,0],          [0,rows-1]])
p2 = np.float32([[0,0], [0.5*(cols-1),0], [0,0.5*(rows-1)]])
#p2 = np.float32([[0,0], [cols*0.8,rows*0.5], [cols*0.15,rows*0.7]])

# 3.估计由输入坐标系到输出坐标系的仿射变换模型
M = cv.getAffineTransform(p1, p2)
print(M)

# 4.利用仿射变换模型，将输入图像仿射变换，产生输出图像
cols2, rows2 = cols, rows              # 此处指定了输出图像的大小与输入一致
imgOutput = cv.warpAffine(imgInput, M, (cols2,rows2))
cv.imwrite('bean_affine.png', imgOutput)

# 5.可视化
cv.imshow('1--input', imgInput)
cv.imshow('2--output', imgOutput)
cv.waitKey(0)
cv.destroyAllWindows()